﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    private static class ProgramBase
    {
        private static Mutex m_Mutex;

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            bool createdNew;
            m_Mutex = new Mutex(true, "MyApplicationMutex", out createdNew);
            if (createdNew)
                Application.Run(new Form1());
            else
                MessageBox.Show("The application is already running.", Application.ProductName,
                  MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
    }
}