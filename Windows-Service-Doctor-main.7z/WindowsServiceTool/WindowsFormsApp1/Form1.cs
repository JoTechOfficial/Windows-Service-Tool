﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using System.Management;
using System.Management.Instrumentation;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("cmd.exe", "/C start cleanmgr.exe /VERYLOWDISK");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Process.Start("ncpa.cpl");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string strCmdText;
            strCmdText = "/K color 9 & wmic os get Caption & wmic cpu get name & wmic path win32_VideoController get name & systeminfo|findstr /C:Memory";
            System.Diagnostics.Process.Start("CMD.exe", strCmdText);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("mmsys.cpl");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("ms-settings:windowsupdate");
            DateTime Tthen = DateTime.Now;
            do
            {
                Application.DoEvents();
            } while (Tthen.AddSeconds(1.13) > DateTime.Now);
            
            System.Diagnostics.Process.Start("CMD.exe", "/C UsoClient StartInteractiveScan");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("ms-settings:appsfeatures");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string message = "Don't Touch Your Keyboard Or Mouse Until A Pop Up Saying (Done) Pops Up. After That You'll See Another Pop Up, Click The Small Box To Enable (Do This For All Current Items) And Select (Skip)";
            string title = "Delete Temp Files";
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.OK)
            {
                System.Diagnostics.Process.Start("CMD.exe", "/C start explorer.exe %temp%");
                DateTime Tthen = DateTime.Now;
                do
                {
                    Application.DoEvents();
                } while (Tthen.AddSeconds(1.85) > DateTime.Now) ;
                SendKeys.Send("^(a)");
                SendKeys.Send("{Delete}");
                {
                    Application.DoEvents();
                } while (Tthen.AddSeconds(3.55) > DateTime.Now) ;
                MessageBox.Show(new Form() { TopMost = true }, "Done");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("cmd.exe", "/C start dfrgui.exe");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.BackColor = Color.Transparent;

            label2.BackColor = Color.Transparent;

            label3.BackColor = Color.Transparent;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("control.exe", "sysdm.cpl,,4");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void gitHubToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://github.com/JoTechOfficial/Windows-Service-Tool");
        }

        private void twitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/JoTechOfficial");
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Show();
                this.Visible = true;
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.Visible = true;
            this.WindowState = FormWindowState.Minimized;
        }

        private void thisIsOneMysteriousLinkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.youtube.com/watch?v=dQw4w9WgXcQ?autoplay=1");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            Hide();
        }
private void runOnStartupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                if (runOnStartupToolStripMenuItem.Checked)
                {
                    MessageBox.Show(new Form() { TopMost = true }, "When (Run On Startup) Is Checked It Gets Added To (Startup Apps)");
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true))
                    {
                        key.SetValue("My Program", "\"" + Application.ExecutablePath + "\"");
                    }
                }
                else
                {
                    MessageBox.Show(new Form() { TopMost = true }, "When (Run On Startup) Is Unchecked It Gets Deleted From (Startup Apps)");
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true))
                    {
                        key.DeleteValue("My Program", false);
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Click Yes If You Have 16GB Of Ram Or More, Click No If You Don't.", "CAUTION: ONLY RUN ONCE", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                System.Diagnostics.Process.Start("CMD.exe", "/C powershell -Command Start-Process PowerShell -Verb RunAs");
                Clipboard.SetText("Disable-MMAgent -mc");

                DateTime Tthen = DateTime.Now;
                do
                {
                    Application.DoEvents();
                } while (Tthen.AddSeconds(1.35) > DateTime.Now);

                MessageBox.Show(new Form() { TopMost = true }, "In Powershell Press (Ctrl & V) at the same time, and then hit enter");
            }
            else if (dialogResult == DialogResult.No)
            {
                this.Visible = true;
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("cmd.exe", "/C start taskmgr /4 /startup");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string message = "This Is For Setting Up New Drives, Deleting Partitions, And Much More. And If System Restore Turns Itself Back On You Can Use This To Get Rid Of The Recovery Partition In CMD (Diskpart).";
            string title = "Disk Management";
            MessageBoxButtons buttons = MessageBoxButtons.OK;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.OK)
            {
                System.Diagnostics.Process.Start("cmd.exe", "/C start diskmgmt");
            }
        }
    }
    }