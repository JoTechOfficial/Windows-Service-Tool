﻿namespace WindowsFormsApp1
{
    internal class onEnd
    {
    }
}