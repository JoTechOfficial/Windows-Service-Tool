﻿namespace WindowsFormsApp1
{
    internal abstract static class WindowsFormsApp1Base
    {
        private static abstract void Main();
    }
}